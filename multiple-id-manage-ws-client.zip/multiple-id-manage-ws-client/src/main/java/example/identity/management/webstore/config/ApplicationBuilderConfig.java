
package example.identity.management.webstore.config;

/** WAR生成のためのクラス
 *
 * @since StvWebStore Ver.1.0
 */
//public class ApplicationBuilderConfig extends SpringBootServletInitializer {
//    @Override
//    protected SpringApplicationBuilder
//        configure(SpringApplicationBuilder application) {
//        return application.sources(Application.class);
//    }
//}