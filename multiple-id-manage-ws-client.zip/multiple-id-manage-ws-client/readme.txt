●npm install
right-click this package.json, then perform 'npm Install'.

